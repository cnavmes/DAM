package com.example.proyectoHibernate.model;

public enum TipoIncidencia {
  LEVE,
  MEDIA,
  URGENTE
}
